import 'dart:convert';
import 'dart:io';

import 'package:ft_music/services/db/db_provider.dart';
import 'package:ft_music/services/import_export_service.dart';

enum RestorePayloadType {
  isarSnapshot,
  legacyFullJson,
  playlistOrTrackJson,
  unsupported,
}

class RestoreBackupOptions {
  final bool restoreMediaItems;
  final bool restoreSearchHistory;
  final bool restoreSettings;

  const RestoreBackupOptions({
    this.restoreMediaItems = true,
    this.restoreSearchHistory = true,
    this.restoreSettings = true,
  });
}

class StorageBackupService {
  const StorageBackupService._();

  static Future<String?> createBackup() {
    return DBProvider.createBackUp();
  }

  static Future<String?> createJsonBackup() {
    return DBProvider.createLegacyJsonBackup();
  }

  static Future<void> resetAppData() {
    return DBProvider.resetDB();
  }

  static Future<Map<String, dynamic>> restoreBackup(
    String? path, {
    RestoreBackupOptions options = const RestoreBackupOptions(),
  }) async {
    if (path == null || path.trim().isEmpty) {
      return {'success': false, 'error': 'No backup file selected.'};
    }

    final file = File(path);
    if (!await file.exists()) {
      return {'success': false, 'error': 'Backup file not found: $path'};
    }

    final payloadType = await detectPayloadType(file);
    switch (payloadType) {
      case RestorePayloadType.isarSnapshot:
        final result = await DBProvider.restoreDB(path);
        if (result['success'] == true) return result;
        // If the Isar schema doesn't match (old version), give clear error
        return {
          'success': false,
          'error': 'This backup is from an older app version with an '
              'incompatible database format. Please export as JSON from '
              'the old version first, then import the JSON file here.',
        };
      case RestorePayloadType.legacyFullJson:
        return DBProvider.restoreLegacyJsonBackup(
          path,
          restoreMediaItems: options.restoreMediaItems,
        );
      case RestorePayloadType.playlistOrTrackJson:
        final imported = await ImportExportService.importJSON(path);
        return {
          'success': imported,
          'mode': 'import',
          if (!imported)
            'error': 'Failed to import playlist/song JSON. Check file format.'
        };
      case RestorePayloadType.unsupported:
        return {
          'success': false,
          'error':
              'Unsupported backup format. Use .isar snapshots, legacy full JSON backup, or playlist/song JSON exports.',
        };
    }
  }

  static Future<RestorePayloadType> detectPayloadType(File file) async {
    final normalizedPath = file.path.toLowerCase();
    final ext = normalizedPath.split('.').last;
    if (ext == 'isar' || ext == 'db' || normalizedPath.endsWith('.isar.db')) {
      return RestorePayloadType.isarSnapshot;
    }

    // Try parsing as JSON first, even if extension doesn't match, to be extremely robust!
    try {
      final content = await file.readAsString();
      final decoded = jsonDecode(content);
      if (decoded is Map<String, dynamic>) {
        final isLegacyFull = decoded.containsKey('playlists') &&
            decoded.containsKey('media_items');
        if (isLegacyFull) {
          return RestorePayloadType.legacyFullJson;
        }

        final isPlaylistExport = decoded.containsKey('playlistName') &&
            (decoded.containsKey('tracks') || decoded.containsKey('mediaItems'));
        final isTrackExport = decoded.containsKey('title') &&
            (decoded.containsKey('mediaId') ||
                decoded.containsKey('duration') ||
                decoded.containsKey('permaURL'));

        if (isPlaylistExport || isTrackExport) {
          return RestorePayloadType.playlistOrTrackJson;
        }
      }
    } catch (_) {}

    if (ext == 'json' || ext == 'blm') {
      return RestorePayloadType.unsupported;
    }

    return RestorePayloadType.unsupported;
  }
}
