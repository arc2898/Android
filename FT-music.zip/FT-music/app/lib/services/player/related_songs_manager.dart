import 'dart:developer';
import 'package:ft_music/core/models/exported.dart';
import 'package:ft_music/plugins/utils/media_id.dart';
import 'package:ft_music/core/constants/setting_keys.dart';
import 'package:ft_music/services/db/db_provider.dart';
import 'package:ft_music/services/db/dao/settings_dao.dart';
import 'package:ft_music/services/player/player_engine.dart';
import 'package:ft_music/services/plugin/plugin_service.dart';
import 'package:ft_music/src/rust/api/plugin/commands.dart';
import 'package:rxdart/rxdart.dart';

class RelatedSongsManager {
  final BehaviorSubject<List<Track>> relatedSongs =
      BehaviorSubject<List<Track>>.seeded([]);
  final PluginService _pluginService;
  final Set<String> _fetchedTrackIds = <String>{};

  String? _referenceTrackId;
  String? _referenceLocalId;
  String? _pluginId;
  String? _nextPageToken;
  bool _isFetching = false;
  bool _isExhausted = false;

  // Callbacks
  Function(List<Track> items, {bool atLast})? onAddQueueItems;

  RelatedSongsManager(this._pluginService);

  Future<void> checkForRelatedSongs({
    required Track currentMedia,
    required List<Track> queue,
    required int currentPlayingIdx,
    required LoopMode loopMode,
  }) async {
    log("Checking for related songs: ${queue.isNotEmpty && (queue.length - currentPlayingIdx) < 2}",
        name: "RelatedSongsManager");

    final autoPlay =
        await SettingsDAO(DBProvider.db).getSettingBool(SettingKeys.autoPlay);
    if (autoPlay != null && !autoPlay) return;

    final shouldQueueMore = queue.isNotEmpty &&
        (queue.length - currentPlayingIdx) < 2 &&
        loopMode != LoopMode.all;
    if (!shouldQueueMore) {
      return;
    }

    final parts = tryParseMediaId(currentMedia.id);
    if (parts == null) {
      return;
    }

    if (parts.pluginId == kLocalPluginId) {
      clearRelatedSongs();
      return;
    }

    _syncReferenceState(
      trackId: currentMedia.id,
      pluginId: parts.pluginId,
      localId: parts.localId,
    );

    if (relatedSongs.value.isEmpty) {
      await _fetchNextRadioPage();
    }

    await loadRelatedSongs(
        queue: queue, currentPlayingIdx: currentPlayingIdx, loopMode: loopMode);

    if (relatedSongs.value.isEmpty) {
      await _fetchNextRadioPage();
      await loadRelatedSongs(
        queue: queue,
        currentPlayingIdx: currentPlayingIdx,
        loopMode: loopMode,
      );
    }
  }

  Future<void> loadRelatedSongs({
    required List<Track> queue,
    required int currentPlayingIdx,
    required LoopMode loopMode,
  }) async {
    if (relatedSongs.value.isNotEmpty &&
        (queue.length - currentPlayingIdx) < 3 &&
        loopMode != LoopMode.all) {
      onAddQueueItems?.call(relatedSongs.value, atLast: true);
      relatedSongs.add([]);
    }
  }

  void clearRelatedSongs() {
    relatedSongs.add([]);
    _fetchedTrackIds.clear();
    _referenceTrackId = null;
    _referenceLocalId = null;
    _pluginId = null;
    _nextPageToken = null;
    _isFetching = false;
    _isExhausted = false;
  }

  void _syncReferenceState({
    required String trackId,
    required String pluginId,
    required String localId,
  }) {
    if (_referenceTrackId == trackId && _pluginId == pluginId) {
      return;
    }

    relatedSongs.add([]);
    _fetchedTrackIds.clear();
    _referenceTrackId = trackId;
    _referenceLocalId = localId;
    _pluginId = pluginId;
    _nextPageToken = null;
    _isFetching = false;
    _isExhausted = false;
  }

  Future<void> _fetchNextRadioPage() async {
    if (_isFetching ||
        _isExhausted ||
        _pluginId == null ||
        _referenceLocalId == null) {
      return;
    }

    _isFetching = true;
    try {
      final response = await _pluginService.execute(
        pluginId: _pluginId!,
        request: PluginRequest.contentResolver(
          ContentResolverCommand.getRadioTracks(
            id: _referenceLocalId!,
            pageToken: _nextPageToken,
          ),
        ),
      );

      response.when(
        moreTracks: (pagedTracks) {
          final uniqueTracks = pagedTracks.items.where((track) {
            return _fetchedTrackIds.add(track.id);
          }).toList(growable: false);

          if (uniqueTracks.isNotEmpty) {
            relatedSongs.add([...relatedSongs.value, ...uniqueTracks]);
            log(
              'Buffered ${uniqueTracks.length} related songs',
              name: 'RelatedSongsManager',
            );
          }

          _nextPageToken = pagedTracks.nextPageToken;
          _isExhausted =
              pagedTracks.nextPageToken == null && uniqueTracks.isEmpty;
        },
        trackDetails: (_) {},
        albumDetails: (_) {},
        artistDetails: (_) {},
        playlistDetails: (_) {},
        streams: (_) {},
        search: (_) {},
        moreAlbums: (_) {},
        homeSections: (_) {},
        loadMoreItems: (_) {},
        charts: (_) {},
        chartDetails: (_) {},
        segments: (_) {},
        lyricsResult: (_) {},
        lyricsSearchResults: (_) {},
        lyricsById: (_, __) {},
        suggestions: (_) {},
        canHandle: (_) {},
        collectionInfo: (_) {},
        importTracks: (_) {},
        ack: () {},
      );
    } catch (e) {
      log('Failed to get related songs: $e', name: 'RelatedSongsManager');
    } finally {
      _isFetching = false;
    }
  }

  void dispose() {
    relatedSongs.close();
  }
}
