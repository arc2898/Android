import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:ft_music/core/models/exported.dart';
import 'package:ft_music/core/theme/app_theme.dart';
import 'package:ft_music/screens/widgets/snackbar.dart';
import 'package:ft_music/services/db/global_db.dart';
import 'package:ft_music/services/db/db_provider.dart';
import 'package:ft_music/services/db/dao/playlist_dao.dart';
import 'package:ft_music/services/db/legacy/legacy_media_id_mapper.dart';
import 'package:ft_music/services/db/dao/track_dao.dart';
import 'package:ft_music/services/m3u_processor.dart';
import 'package:ft_music/services/storage_backup_service.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:ft_music/l10n/app_localizations.dart';

/// Service for importing and exporting playlists and tracks.
///
/// Exports/imports use a JSON format with track data serialized from the
/// new [TrackDB] schema. Old `MediaItemDB` format files are handled via
/// a backward-compatible import path.
class ImportExportService {
  static PlaylistDAO get _playlistDao =>
      PlaylistDAO(DBProvider.db, TrackDAO(DBProvider.db));

  // ── Helpers ────────────────────────────────────────────────────────────────

  /// Checks if a playlist with the given name already exists in the library.
  static Future<bool> isPlaylistExists(String playlistName) async {
    final existing = await _playlistDao.getPlaylistByName(playlistName);
    return existing != null;
  }

  /// Serialize a [TrackDB] into a portable JSON map.
  static Map<String, dynamic> _trackDBToMap(TrackDB t) {
    return {
      'mediaId': t.mediaId,
      'title': t.title,
      'artists': t.artists
              ?.map((a) => {
                    'name': a.name,
                    'url': a.url,
                    'mediaId': a.mediaId,
                  })
              .toList() ??
          [],
      'album': t.album != null
          ? {
              'title': t.album!.name,
              'url': t.album!.url,
              'mediaId': t.album!.mediaId,
              'year': t.album!.year,
            }
          : null,
      'thumbnail': t.thumbnail != null
          ? {
              'url': t.thumbnail!.url,
              'urlLow': t.thumbnail!.urlLow,
              'urlHigh': t.thumbnail!.urlHigh,
            }
          : null,
      'durationMs': t.durationMs,
      'genre': t.genre,
      'language': t.language,
      'isExplicit': t.isExplicit,
    };
  }

  /// Deserialize a JSON map into a domain [Track].
  ///
  /// Handles both new format (artists list, thumbnail map) and legacy
  /// `MediaItemDB` format (artist string, artURL, etc.).
  static Track _trackFromMap(Map<String, dynamic> m) {
    // ── New format ───────────────────────────────────────────────────────────
    if (m.containsKey('mediaId') &&
        m.containsKey('artists') &&
        m['artists'] is List) {
      final artistsList = (m['artists'] as List)
          .map((a) => ArtistSummary(
                id: (a['mediaId'] as String?) ?? '',
                name: (a['name'] as String?) ?? '',
                url: a['url'] as String?,
              ))
          .toList();

      AlbumSummary? album;
      if (m['album'] is Map) {
        final a = m['album'] as Map;
        album = AlbumSummary(
          id: (a['mediaId'] as String?) ?? '',
          title: (a['title'] as String?) ?? '',
          artists: const [],
          url: a['url'] as String?,
        );
      }

      Artwork thumbnail = Artwork(url: '', layout: ImageLayout.square);
      if (m['thumbnail'] is Map) {
        final t = m['thumbnail'] as Map;
        thumbnail = Artwork(
          url: (t['url'] as String?) ?? '',
          urlLow: t['urlLow'] as String?,
          urlHigh: t['urlHigh'] as String?,
          layout: ImageLayout.square,
        );
      }

      return Track(
        id: m['mediaId'] as String? ?? '',
        title: m['title'] as String? ?? '',
        artists: artistsList,
        album: album,
        thumbnail: thumbnail,
        durationMs: m['durationMs'] != null
            ? BigInt.from(m['durationMs'] as int)
            : null,
        isExplicit: m['isExplicit'] as bool? ?? false,
      );
    }

    // ── Legacy MediaItemDB format ────────────────────────────────────────────
    final mappedId = buildPluginScopedMediaIdFromLegacyMap(m);
    final fallbackId = (m['mediaID'] as String?) ??
        (m['mediaId'] as String?) ??
        (m['id'] as String?) ??
        (m['permaURL'] as String?) ??
        '';
    final id =
        (mappedId != null && mappedId.isNotEmpty) ? mappedId : fallbackId;
    final title = (m['title'] as String?) ?? '';
    final artist = (m['artist'] as String?) ?? '';
    final album = (m['album'] as String?) ?? '';
    final artURL = (m['artURL'] as String?) ?? '';
    final durationSec = m['duration'] as num?;

    return Track(
      id: id,
      title: title,
      artists: artist.isNotEmpty
          ? artist
              .split(', ')
              .map((n) => ArtistSummary(id: '', name: n))
              .toList()
          : [],
      album: album.isNotEmpty
          ? AlbumSummary(id: '', title: album, artists: const [])
          : null,
      thumbnail: Artwork(url: artURL, layout: ImageLayout.square),
      durationMs: durationSec != null
          ? BigInt.from((durationSec * 1000).toInt())
          : null,
      isExplicit: false,
    );
  }

  // ── Export ──────────────────────────────────────────────────────────────────

  /// Exports a playlist to a JSON file.
  static Future<String?> exportPlaylist(String playlistName,
      {String? filePath}) async {
    final playlistDB = await _playlistDao.getPlaylistByName(playlistName);
    if (playlistDB == null) {
      log("Playlist not found", name: "FileManager");
      return null;
    }

    try {
      final tracks = await _playlistDao.getPlaylistTracks(playlistDB.id);
      final packageInfo = await PackageInfo.fromPlatform();

      final Map<String, dynamic> playlistMap = {
        '_meta': {
          'generated_by': 'FT-music - Open Source Music Streaming Application',
          'version':
              'v${packageInfo.version}+${int.parse(packageInfo.buildNumber) % 1000}',
          'exportedAt': DateTime.now().toIso8601String(),
          'format': 'v2',
          'note':
              'This file is automatically generated by FT-music and is intended solely for importing playlists within FT-music.',
        },
        'playlistName': playlistDB.name,
        'tracks': tracks.map((t) => _trackDBToMap(t)).toList(),
      };

      final path = await writeToJSON(
          '${playlistDB.name}_FTMusicPlaylist.json', playlistMap,
          path: filePath);
      log("Playlist exported successfully", name: "FileManager");
      return path;
    } catch (e) {
      log("Error exporting playlist: $e");
      return null;
    }
  }

  /// Exports a single track to a JSON file.
  static Future<String?> exportTrack(TrackDB trackDB) async {
    try {
      final Map<String, dynamic> trackMap = _trackDBToMap(trackDB);
      final packageInfo = await PackageInfo.fromPlatform();
      trackMap['_meta'] = {
        'generated_by': 'FT-music - Open Source Music Streaming Application',
        'version':
            'v${packageInfo.version}+${int.parse(packageInfo.buildNumber) % 1000}',
        'exportedAt': DateTime.now().toIso8601String(),
        'format': 'v2',
      };

      final path =
          await writeToJSON('${trackDB.title}_FTMusicSong.json', trackMap);
      log("Track exported successfully", name: "FileManager");
      return path;
    } catch (e) {
      log("Error exporting track: $e", name: "FileManager");
      return null;
    }
  }

  // ── Import ─────────────────────────────────────────────────────────────────

  /// Imports a playlist from a JSON file.
  static Future<bool> importPlaylist(String filePath) async {
    try {
      final playlistMap = await readFromJSON(filePath);
      if (playlistMap == null || playlistMap.isEmpty) return false;

      // Determine format
      final isV2 = playlistMap.containsKey('tracks');
      final isV1 = playlistMap.containsKey('mediaItems');
      if (!isV2 && !isV1) {
        throw const FormatException("Missing 'tracks' or 'mediaItems' key.");
      }

      final String baseName = playlistMap['playlistName'] ?? 'Imported';

      // Deduplicate playlist name.
      String playlistName = baseName;
      int i = 1;
      while (await isPlaylistExists(playlistName)) {
        playlistName = '${baseName}_$i';
        i++;
      }

      final playlistId = await _playlistDao.ensurePlaylist(playlistName);
      final items = (playlistMap[isV2 ? 'tracks' : 'mediaItems'] as List);
      final tracks = <Track>[];

      for (final item in items) {
        if (item is Map<String, dynamic>) {
          final track = _trackFromMap(item);
          tracks.add(track);
        }
      }

      await _playlistDao.addTracksToPlaylist(playlistId, tracks);

      log("Playlist imported successfully");
      return true;
    } catch (e) {
      log("Invalid file format: $e");
      SnackbarService.showMessage(
          "Invalid file format. Please check the file and try again.");
      return false;
    }
  }

  /// Imports a single track from a JSON file.
  static Future<bool> importMediaItem(String filePath) async {
    try {
      final trackMap = await readFromJSON(filePath);
      if (trackMap == null || trackMap.isEmpty) return false;

      final track = _trackFromMap(trackMap);
      final playlistId = await _playlistDao.ensurePlaylist("Imported");
      await _playlistDao.addTracksToPlaylist(playlistId, [track]);
      log("Track imported successfully");
      return true;
    } catch (e) {
      log("Invalid file format");
      return false;
    }
  }

  /// Automatically determines the type of JSON file and imports it.
  static Future<bool> importJSON(String filePath) async {
    try {
      final data = await readFromJSON(filePath);
      if (data == null || data.isEmpty) {
        throw const FormatException("Invalid or empty JSON file.");
      }

      if (data.containsKey('playlistName') &&
          (data.containsKey('tracks') || data.containsKey('mediaItems'))) {
        return await importPlaylist(filePath);
      } else if (data.containsKey('title') &&
          (data.containsKey('mediaId') || data.containsKey('duration'))) {
        return await importMediaItem(filePath);
      } else if (data.containsKey('playlists') &&
          data.containsKey('media_items')) {
        final result = await DBProvider.restoreLegacyJsonBackup(filePath);
        return result['success'] == true;
      } else {
        throw const FormatException("Unrecognized JSON structure.");
      }
    } catch (e) {
      log("Error importing JSON file: $e", name: "FileManager");
      SnackbarService.showMessage(
          "Failed to import file. Please check the file and try again.");
      return false;
    }
  }

  // ── M3U Export ─────────────────────────────────────────────────────────────

  /// Export playlist as M3U/M3U8.
  static Future<String?> exportM3UPlaylist(String playlistName) async {
    final playlistDB = await _playlistDao.getPlaylistByName(playlistName);
    if (playlistDB == null) {
      log("Playlist not found", name: "FileManager");
      return null;
    }

    try {
      final tracks = await _playlistDao.getPlaylistTracks(playlistDB.id);
      final packageInfo = await PackageInfo.fromPlatform();

      // Build a legacy-shaped JSON map for the M3U converter.
      final Map<String, dynamic> playlistMap = {
        '_meta': {
          'generated_by': 'FT-music - Open Source Music Streaming Application',
          'version':
              'v${packageInfo.version}+${int.parse(packageInfo.buildNumber) % 1000}',
          'exportedAt': DateTime.now().toIso8601String(),
        },
        'playlistName': playlistDB.name,
        'mediaItems': tracks.map((t) {
          final artistStr =
              t.artists?.map((a) => a.name ?? '').join(', ') ?? '';
          return {
            'title': t.title,
            'artist': artistStr,
            'album': t.album?.name ?? '',
            'genre': t.genre ?? '',
            'artURL': t.thumbnail?.url ?? '',
            'duration': (t.durationMs ?? 0) ~/ 1000,
            'streamingURL': '',
            'permaURL': t.mediaId,
          };
        }).toList(),
      };

      final String m3uData = convertJsonToM3U(playlistMap);
      final path = await writeToM3U('${playlistDB.name}.m3u', m3uData);
      log("Playlist exported as M3U successfully", name: "FileManager");
      return path;
    } catch (e) {
      log("Error exporting playlist as M3U: $e");
      return null;
    }
  }

  // ── File I/O ───────────────────────────────────────────────────────────────
  static Future<String?> writeToJSON(String fileName, Map<String, dynamic> data,
      {String? path}) async {
    try {
      final filePath = path ?? (await getApplicationCacheDirectory()).path;
      final file = File('$filePath/$fileName');
      await file.writeAsString(jsonEncode(data));
      log("Data written to file: $filePath/$fileName", name: "FileManager");
      return '$filePath/$fileName';
    } catch (e) {
      log("Error writing file:", error: e, name: "FileManager");
      return null;
    }
  }

  /// Reads data from a JSON file and returns it as a map.
  ///
  /// [filePath] - The path of the file to read.
  /// Returns the data as a map, or `null` if an error occurs.
  static Future<Map<String, dynamic>?> readFromJSON(String filePath) async {
    try {
      final file = File(filePath);
      final data = await file.readAsString();
      log("Data read from file: $filePath", name: "FileManager");
      return jsonDecode(data);
    } catch (e) {
      log("Error reading file:", error: e);
      return null;
    }
  }

  /// Validates the structure of a playlist JSON file (supports both v1 and v2).
  static void validatePlaylistJson(Map<String, dynamic> playlistMap) {
    if (!playlistMap.containsKey('playlistName') ||
        playlistMap['playlistName'] == null) {
      throw const FormatException("Invalid JSON: Missing 'playlistName'.");
    }

    final hasV2 = playlistMap.containsKey('tracks');
    final hasV1 = playlistMap.containsKey('mediaItems');
    if (!hasV2 && !hasV1) {
      throw const FormatException(
          "Invalid JSON: Missing 'tracks' or 'mediaItems'.");
    }

    final items = playlistMap[hasV2 ? 'tracks' : 'mediaItems'];
    if (items is! List) {
      throw const FormatException("Invalid JSON: items must be a list.");
    }

    for (final item in items) {
      if (item is! Map<String, dynamic>) {
        throw const FormatException("Invalid JSON: Each item must be a map.");
      }
      if (!item.containsKey('title') && !item.containsKey('mediaId')) {
        throw const FormatException(
            "Invalid JSON: item missing 'title' or 'mediaId'.");
      }
    }
  }

  static Future<String?> writeToM3U(String fileName, String data) async {
    try {
      final filePath = (await getApplicationCacheDirectory()).path;
      final file = File('$filePath/$fileName');
      await file.writeAsString(data);
      log("Data written to file: $filePath/$fileName", name: "FileManager");
      return '$filePath/$fileName';
    } catch (e) {
      log("Error writing file:", error: e, name: "FileManager");
      return null;
    }
  }

  /// Production-level entry point to handle any shared or picked import/restore file.
  /// Handles: Isar snapshots (.isar/.db), legacy full JSON backups, and playlist/song JSON exports.
  static Future<void> handleImportOrRestore(
      BuildContext context, String filePath) async {
    final l10n = AppLocalizations.of(context)!;
    try {
      final file = File(filePath);
      if (!await file.exists()) {
        SnackbarService.showMessage(l10n.storageRestoreNoFile);
        return;
      }

      final payloadType = await StorageBackupService.detectPayloadType(file);

      switch (payloadType) {
        case RestorePayloadType.isarSnapshot:
          if (!context.mounted) return;
          final confirm = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: const Color.fromARGB(255, 24, 24, 24),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text(
                l10n.storageRestoreConfirmTitle,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18),
              ),
              content: Text(
                "${l10n.storageRestoreConfirmPrefix}\n\n${l10n.storageRestoreMediaBullet}\n${l10n.storageRestoreHistoryBullet}\n\n${l10n.storageRestoreConfirmSuffix}",
                style: const TextStyle(
                    color: Colors.white70, fontSize: 14, height: 1.5),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(l10n.storageRestoreNo,
                      style: const TextStyle(color: Colors.white70)),
                ),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Default_Theme.accentColor2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text(l10n.storageRestoreYes,
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          );

          if (confirm != true) return;
          if (!context.mounted) return;

          // Show progress dialog
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (ctx) => WillPopScope(
              onWillPop: () async => false,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 24, 24, 24),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(
                          color: Default_Theme.accentColor2),
                      const SizedBox(height: 16),
                      Text(l10n.storageRestoring,
                          style: const TextStyle(
                              color: Colors.white,
                              decoration: TextDecoration.none,
                              fontSize: 14),
                          textAlign: TextAlign.center),
                    ],
                  ),
                ),
              ),
            ),
          );

          final result = await StorageBackupService.restoreBackup(filePath);
          if (!context.mounted) return;
          Navigator.pop(context); // Dismiss progress dialog

          final success = result['success'] == true;
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: const Color.fromARGB(255, 24, 24, 24),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text(
                success
                    ? l10n.storageRestoreCompleted
                    : l10n.storageRestoreFailedTitle,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18),
              ),
              content: Text(
                success
                    ? l10n.storageRestoreSuccessMessage
                    : "${l10n.storageRestoreFailedMessage}\n- ${result['error'] ?? l10n.storageRestoreUnknownError}",
                style: const TextStyle(
                    color: Colors.white70, fontSize: 14, height: 1.5),
              ),
              actions: [
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Default_Theme.accentColor2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Navigator.pop(ctx),
                  child: Text(l10n.buttonOk,
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          );
          break;

        case RestorePayloadType.legacyFullJson:
          if (!context.mounted) return;
          final confirm = await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: const Color.fromARGB(255, 24, 24, 24),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text(
                l10n.storageRestoreConfirmTitle,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18),
              ),
              content: Text(
                "${l10n.storageRestoreConfirmPrefix}\n\n${l10n.storageRestoreMediaBullet}\n\n${l10n.storageRestoreConfirmSuffix}",
                style: const TextStyle(
                    color: Colors.white70, fontSize: 14, height: 1.5),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text(l10n.storageRestoreNo,
                      style: const TextStyle(color: Colors.white70)),
                ),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Default_Theme.accentColor2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text(l10n.storageRestoreYes,
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          );

          if (confirm != true) return;
          if (!context.mounted) return;

          // Show progress dialog
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (ctx) => WillPopScope(
              onWillPop: () async => false,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 24, 24, 24),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(
                          color: Default_Theme.accentColor2),
                      const SizedBox(height: 16),
                      Text(l10n.storageRestoring,
                          style: const TextStyle(
                              color: Colors.white,
                              decoration: TextDecoration.none,
                              fontSize: 14),
                          textAlign: TextAlign.center),
                    ],
                  ),
                ),
              ),
            ),
          );

          final result = await DBProvider.restoreLegacyJsonBackup(filePath);
          if (!context.mounted) return;
          Navigator.pop(context); // Dismiss progress dialog

          final success = result['success'] == true;
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              backgroundColor: const Color.fromARGB(255, 24, 24, 24),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)),
              title: Text(
                success
                    ? l10n.storageRestoreCompleted
                    : l10n.storageRestoreFailedTitle,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 18),
              ),
              content: Text(
                success
                    ? l10n.storageRestoreSuccessMessage
                    : "${l10n.storageRestoreFailedMessage}\n- ${result['error'] ?? l10n.storageRestoreUnknownError}",
                style: const TextStyle(
                    color: Colors.white70, fontSize: 14, height: 1.5),
              ),
              actions: [
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Default_Theme.accentColor2,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Navigator.pop(ctx),
                  child: Text(l10n.buttonOk,
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ],
            ),
          );
          break;

        case RestorePayloadType.playlistOrTrackJson:
          SnackbarService.showMessage(l10n.snackbarImportingMedia);
          final res = await importJSON(filePath);
          if (res) {
            SnackbarService.showMessage(l10n.snackbarImportCompleted);
          }
          break;

        case RestorePayloadType.unsupported:
          SnackbarService.showMessage(l10n.snackbarInvalidFileFormat);
          break;
      }
    } catch (e) {
      log("Error during import/restore: $e", name: "ImportExportService");
      SnackbarService.showMessage(l10n.storageUnexpectedError);
    }
  }
}
